//
//  ProfileScreen.swift
//  Assignment
//
//  Created by IACD Training 1 on 2024/04/03.
//

import SwiftUI

struct ProfileScreen: View {
    var body: some View {
        
        VStack{
            
            Image("mypic")
            
                .resizable()
            
                .scaledToFit()
            
            Text("Karabo Kekabo")
                .foregroundColor(Color.white)
                .font(.system(size: 35))
            Text("Software Developer")
                .foregroundColor(Color.white)
                .font(.system(size: 35))
            Text("Mpilo Technologies")
                .foregroundColor(Color.white)
                .font(.system(size: 35))
                
            
                
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)        .background(Color.red)
        
    }
        
    
}


#Preview {
    ProfileScreen()
}
