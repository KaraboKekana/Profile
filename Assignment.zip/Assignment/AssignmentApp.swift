//
//  AssignmentApp.swift
//  Assignment
//
//  Created by IACD Training 1 on 2024/04/03.
//

import SwiftUI

@main
struct AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
