//
//  ContentView.swift
//  Assignment
//
//  Created by IACD Training 1 on 2024/04/03.
//

import SwiftUI

 
let appearance = UITabBarAppearance()
struct ContentView: View {

    var body: some View {

        VStack {

            TabView{
                
               
                
                ProfileScreen()
                
                .tabItem {
                    
                    Label(
                        "Profile",
                        systemImage: "person"
                    )
                }
                
                SkillsScreen()
                .tabItem {
                    
                    Label(
                        "Profile",
                        systemImage: "book"
                    )
                    
                }
                
                
               ContactDetailsSreens()
                .tabItem {
                    
                    Label(
                        "Contacts",
                        systemImage: "phone"
                
                    )
                }
                
                
                
                .frame(
                    maxWidth: .infinity,
                    maxHeight: .infinity
                )
                
                
            }
            
        }
        
        .padding()
        .background(
            Color.red
        )

    }

}

#Preview {
    ContentView()
}
