//
//  ContactDetailsSreens.swift
//  Assignment
//
//  Created by IACD Training 1 on 2024/04/03.
//

import SwiftUI

struct ContactDetailsSreens: View {
     
    var body: some View {
        let myHeight: Double = 500.0
        let myWidth: Double = 400.0
        VStack{
        Text("Contact Details")
            .fontWeight(.bold)
            .font(.system(size: 35))
            .foregroundColor(Color.white)
        Spacer()
        
        List {
    
        Text("Cell NO: 0723856430")
        Text("Email Address:mkk@gmail.com")
        Text("Linkedin: likedin.com/in/karabo-kekana-693881206")
        }
            Spacer()
        .padding()
        .frame(maxWidth: myWidth, maxHeight: myHeight)     .background(Color.red)
        
    }
    .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)     .background(Color.red)
}

}

#Preview {
    ContactDetailsSreens()
}
