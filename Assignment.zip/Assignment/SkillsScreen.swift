//
//  SkillsScreen.swift
//  Assignment
//
//  Created by IACD Training 1 on 2024/04/03.
//

import SwiftUI

struct SkillsScreen: View {
    var body: some View {
        let myHeight: Double = 300.0
        let myWidth: Double = 400.0
        VStack{
        Text("Skills")
            .fontWeight(.bold)
            .font(.system(size: 35))
            .foregroundColor(Color.white)
        Spacer()
        
        List {
        Text("Network Troubleshooting")
        Text("SQL")
        Text("Java")
        Text("C++")
        Text("HTML")
        Text("Applications Design")
        Text("PostgressSQL")
       
            
        }
            Spacer()
            .padding()
                .frame(maxWidth: myWidth, maxHeight: myHeight)     .background(Color.red)
            
        }
        .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)     .background(Color.red)
    }
    
}

#Preview {
    SkillsScreen()
}
